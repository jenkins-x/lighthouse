{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "webhooks.name" -}}
{{- $name := default "webhooks" .Values.webhooks.nameOverride -}}
{{- printf "%s-%s" .Chart.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
*/}}
{{- define "fullname" -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "keeper.name" -}}
{{- $name := default "keeper" .Values.keeper.nameOverride -}}
{{- printf "%s-%s" .Chart.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "poller.name" -}}
{{- $name := default "poller" .Values.poller.nameOverride -}}
{{- printf "%s-%s" .Chart.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "foghorn.name" -}}
{{- $name := default "foghorn" .Values.foghorn.nameOverride -}}
{{- printf "%s-%s" .Chart.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "gcJobs.name" -}}
{{- $name := default "gc-jobs" .Values.gcJobs.nameOverride -}}
{{- printf "%s-%s" .Chart.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "tektoncontroller.name" -}}
{{- $name := default "tekton-controller" .Values.tektoncontroller.nameOverride -}}
{{- printf "%s-%s" .Chart.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "jenkinscontroller.name" -}}
{{- $name := default "jenkins-controller" .Values.jenkinscontroller.nameOverride -}}
{{- printf "%s-%s" .Chart.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Fail on the removed githubApp values rather than silently falling back to a static token.
*/}}
{{- define "lighthouse.checkRemovedValues" -}}
{{- if (.Values.githubApp).enabled -}}
{{- fail "githubApp.enabled has been removed; configure a token with oauthToken or oauthSecretName" -}}
{{- end -}}
{{- end -}}
